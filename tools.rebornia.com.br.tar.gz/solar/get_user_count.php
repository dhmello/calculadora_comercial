<?php
require 'init.php';

$stmt = $pdo->query("SELECT COUNT(*) FROM active_users");
echo $stmt->fetchColumn();
?>
