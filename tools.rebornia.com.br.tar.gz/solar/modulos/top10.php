<div class="container">
    <div class="card full-width-card" style="max-width: 600px; margin: 0 auto;">
        <div class="card-header header-row">
            <h6 class="mb-0">TOP 10</h6>
        </div>
        <div class="card-body">
            <form id="top10-calculo-form">
                <div class="form-group">
                    <label for="a3">< 20%</label>
                    <input type="number" class="form-control" id="a3" placeholder="0">
                </div>
                <div class="form-group">
                    <label for="b3">20% A 34%</label>
                    <input type="number" class="form-control" id="b3" placeholder="0">
                </div>
                <div class="form-group">
                    <label for="c3">35% A 49%</label>
                    <input type="number" class="form-control" id="c3" placeholder="0">
                </div>
                <div class="form-group">
                    <label for="d3">> 50%</label>
                    <input type="number" class="form-control" id="d3" placeholder="0">
                </div>
            </form>

            <table class="table table-bordered mt-4">
                <thead>
                    <tr>
                        <th>SOMA</th>
                        <th>FORMULA</th>
                    </tr>
                </thead>
                <tbody id="top10-calculo-result">
                    <tr>
                        <td id="soma">0</td>
                        <td id="formula" class="green-cell">0,00%</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const inputs = ['a3', 'b3', 'c3', 'd3'];
    
    inputs.forEach(id => {
        document.getElementById(id).addEventListener('input', updateTop10Results);
    });

    function updateTop10Results() {
        const a3 = parseInt(document.getElementById('a3').value) || 0;
        const b3 = parseInt(document.getElementById('b3').value) || 0;
        const c3 = parseInt(document.getElementById('c3').value) || 0;
        const d3 = parseInt(document.getElementById('d3').value) || 0;

        const soma = a3 + b3 + c3 + d3;
        document.getElementById('soma').textContent = soma;

        let formula = 0;
        if (a3 === 2 && d3 >= 5 && (b3 + c3 + d3) === 8 && (c3 + d3) >= 7) {
            formula = 95;
        } else if (a3 === 1 && d3 >= 5 && (b3 + c3 + d3) === 9 && (c3 + d3) >= 7) {
            formula = 100;
        } else if (a3 === 0 && d3 >= 5 && (b3 + c3 + d3) === 10 && (c3 + d3) >= 7) {
            formula = 110;
        }

        document.getElementById('formula').textContent = formula > 0 ? `${formula.toFixed(2)}%` : `0,00%`;
    }
});
</script>
