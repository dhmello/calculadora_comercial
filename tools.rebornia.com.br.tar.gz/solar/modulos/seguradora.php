<div class="tab-pane fade show active" id="seguradora" role="tabpanel" aria-labelledby="seguradora-tab">
    <div class="card full-width-card" style="max-width: 600px; margin: 0 auto;">
        <div class="card-header header-row">
            <h6 class="mb-0">SEGURADORA CÁLCULO</h6>
        </div>
        <div class="card-body">
            <form id="seguradora-calculo-form">
                <div class="form-group">
                    <label for="valor-item-seguradora">Valor do Item:</label>
                    <input type="number" class="form-control" id="valor-item-seguradora" placeholder="R$ 0,00">
                </div>
                <div class="form-group text-center">
                    <img src="assets/img/seguradora.png" alt="Logo do Mercado Pago" id="seguradora-logo" style="max-width: 250px; margin-top: 10px;">
                </div>
            </form>

            <table class="table table-bordered mt-4">
                <thead>
                    <tr>
                        <th>Parcelas</th>
                        <th>Valor Total</th>
                        <th>Valor da Parcela</th>
                    </tr>
                </thead>
                <tbody id="seguradora-calculo-result">
                    <!-- Resultados aparecerão aqui -->
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
function calculateseguradora(juros) {
    const valorItem = parseFloat(document.getElementById('valor-item-seguradora').value) || 0;
    const resultContainer = document.getElementById('seguradora-calculo-result');
    resultContainer.innerHTML = '';

    juros.forEach(item => {
        const parcelas = parseInt(item.descricao.replace(/\D/g, '')) || 1; // Extrai o número de parcelas da descrição

        // Calcular o valor total e o valor da parcela
        const valorTotal = valorItem * (1 + item.juros / 100);
        const valorParcela = valorTotal / parcelas;

        resultContainer.innerHTML += `
            <tr>
                <td>${item.descricao}</td>
                <td>R$ ${valorTotal.toFixed(2)}</td>
                <td>R$ ${valorParcela.toFixed(2)}</td>
            </tr>`;
    });
}

function loadJurosseguradora() {
    fetch('juros_seguradora.php')
        .then(response => response.json())
        .then(data => {
            document.getElementById('valor-item-seguradora').addEventListener('input', function() {
                calculateseguradora(data);
            });
        });
}

document.addEventListener('DOMContentLoaded', function() {
    loadJurosseguradora();
});
</script>
