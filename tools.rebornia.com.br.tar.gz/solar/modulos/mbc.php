<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Cálculo MBC</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        /* Estilo personalizado para o módulo MBC */
        .container {
            margin-top: 50px;
        }
        .full-width-card {
            max-width: 600px;
            margin: 0 auto;
        }
        .header-row {
            background-color: #007bff;
            color: white;
            padding: 15px;
            border-radius: 5px 5px 0 0;
        }
        .table th, .table td {
            text-align: center;
        }
        .table thead th {
            background-color: #007bff;
            color: white;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="card full-width-card">
        <div class="card-header header-row">
            <h6 class="mb-0">MBC CÁLCULO</h6>
        </div>
        <div class="card-body">
            <form id="mbc-calculo-form">
                <div class="form-group">
                    <label for="valor-item">Valor do Item:</label>
                    <input type="number" class="form-control" id="valor-item" placeholder="R$ 0,00">
                </div>
                <div class="form-group text-center">
                    <img src="assets/img/mbc.png" alt="Logo do MBC" id="mbc-logo" style="max-width: 250px; margin-top: 10px;">
                </div>
            </form>

            <table class="table table-bordered mt-4">
                <thead>
                    <tr>
                        <th>Parcelas</th>
                        <th>Valor Total</th>
                        <th>Valor da Parcela</th>
                    </tr>
                </thead>
                <tbody id="mbc-calculo-result">
                    <!-- Resultados aparecerão aqui -->
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
// Função para carregar juros do banco de dados
function loadJuros() {
    fetch('juros_mbc.php')
        .then(response => response.json())
        .then(jurosMBC => {
            document.getElementById('valor-item').addEventListener('input', function() {
                calculateMBC(jurosMBC);
            });

            // Calcular imediatamente caso já tenha um valor preenchido
            calculateMBC(jurosMBC);
        })
        .catch(error => console.error('Erro ao carregar os dados dos juros:', error));
}

function calculateMBC(jurosMBC) {
    const valorItem = parseFloat(document.getElementById('valor-item').value) || 0;
    const resultContainer = document.getElementById('mbc-calculo-result');
    resultContainer.innerHTML = '';

    if (valorItem > 0) {
        jurosMBC.forEach(item => {
            const parcelas = item.parcelas; // Utilizando a quantidade de parcelas do banco de dados
            const valorTotal = valorItem * (1 + item.juros / 100);
            const valorParcela = valorTotal / parcelas;

            resultContainer.innerHTML += `
                <tr>
                    <td>${item.descricao}</td>
                    <td>R$ ${valorTotal.toFixed(2).replace('.', ',')}</td>
                    <td>R$ ${valorParcela.toFixed(2).replace('.', ',')}</td>
                </tr>`;
        });
    }
}

document.addEventListener('DOMContentLoaded', function() {
    loadJuros();  // Carregar os juros ao carregar a página
});
</script>

</body>
</html>
